import axios from "axios";
import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { toast } from "react-toastify";

function Categories() {
    const [catdata, setcatdata] = useState([])
    async function getallcat() {
        try {
            const resp = await axios.get("http://localhost:9000/api/getallcat")
            if (resp.status === 200) {
                if (resp.data.statuscode === 1) {
                    setcatdata(resp.data.categorydata)
                }
                else if (resp.data.statuscode === 0) {
                    setcatdata([]);
                }
            }
            else {
                toast.warn("spme problem occured")
            }
        }
        catch (e) {
            toast.warn(e.message)
        }
    }

    useEffect(() => {
        getallcat();
    }, [])

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/homepage"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Category</li>
                    </ol>
                </div>
            </div>
            <div className="login">
                <div className="container">
                    {
                        catdata.length > 0 ?
                            <>
                                {
                                    catdata.map((item, index) =>
                                        <div className="col-md-4 top_brand_left" key={index}>
                                            <div className="hover14 column">
                                                <div className="agile_top_brand_left_grid">
                                                    <div className="agile_top_brand_left_grid1">
                                                        <figure>
                                                            <div className="snipcart-item block" >
                                                                <div className="snipcart-thumb">
                                                                    <Link to={`/subcategory?cat=${item._id}`}>
                                                                        <img src={`uploads/${item.catpic}`} height="125" title=" " alt=" "></img>
                                                                        <p>{item.catname}</p>
                                                                    </Link>
                                                                </div>
                                                                <div className="snipcart-details top_brand_home_details ">
                                                                </div>
                                                            </div>
                                                        </figure>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                }
                            </> : <h2>No product is added by Admin</h2>
                    }

                </div>
            </div>
        </>
    )
}
export default Categories;