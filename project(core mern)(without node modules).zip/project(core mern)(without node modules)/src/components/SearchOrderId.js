import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";


function SearchOrderId() 
{

    const[orderid , setorderid]=useState();
    const[orderdata , setorderdata] = useState([]);
    const[billamt , setbillamt] = useState([])

    const navi = useNavigate();

    async function onsearch(e)
    {
        e.preventDefault()
        try
        {
            const resp = await axios.get(`http://localhost:9000/api/SearchOrderId?un=${orderid}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===0)
                {
                    toast.error("No Order-Id Found");
                    setorderdata([])
                }
                else if(resp.data.statuscode===1)
                {
                    toast.success(" Order-Id Found");
                    setorderdata(resp.data.proddata)
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }
        catch(e)
        {
            alert(e.message)
        }
    }


    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])

    useEffect(()=>
    {
        // 0+76,0+765,0+456 ans will be 456(last one) in asynchronous function
        var gtotal=0;
        for(var x=0;x<orderdata.length;x++) // it is synchronous function
        {
            gtotal=gtotal+orderdata[x].billamt;  
        }
        setbillamt(gtotal);
        
    } , [orderdata])

    async function onorderdel(id)
    {
        var userresp = window.confirm("Are you sure to Delete")

        if(userresp===true)
        {
            const resp = await axios.delete(`http://localhost:9000/api/delorder/${id}`)
            if(resp.status===200)
            {
                if(resp.data.statuscode===1)
                {
                    toast.success("Order Deleted Successfull")
                    onsearch();
                }
                else if(resp.data.statuscode===0)
                {
                    alert("Order not Deleted")
                }
            }
            else
            {
                alert("Some Problem Occured")
            }
        }  
    }

    async function updatestatus(id)
    {
        navi("/updatestatus?oid=" + id)
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Order-Id</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <h2>Search Order-Id</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                        <form name="form1" onSubmit={onsearch}>
                            <input type="text" name="un" placeholder="Enter Order Id" required=" " onChange={(e)=>setorderid(e.target.value)}/>
                            <input type="submit" name="btn" value="Search" /><br/><br/>
                        </form>
                    </div><br/><br/>
                        {
                            orderdata.length>0?
                            <>
                                <h2>Order</h2><br/>
                                <table className="table table-striped timetable_sub">
                                    <tbody>
                                        <tr>
                                            <th>Order ID</th>
                                            <th>State</th>
                                            <th>Address</th>
                                            <th>Pincode</th>
                                            <th>Bill Amount</th>
                                            <th>Username</th>
                                            <th>Date</th>
                                            <th>Payment Mode</th>
                                            <th>Status</th>
                                            <th>Update Status</th>
                                            <th>Delete</th>
                                        </tr>
                                    </tbody>
                                {
                                    orderdata.map((item , index)=>
                                        <tr key={index}>
                                            <td><Link to={`/vieworderitems?oid=${item._id}`}>{item._id}</Link></td>
                                            <td>{item.address.state }</td>
                                            <td>{item.address.area }</td>
                                            <td>{item.address.pincode}</td>
                                            <td>{item.billamt}</td>
                                            <td>{item.username}</td>
                                            <td>{item.OrderDate}</td>
                                            <td>{item.PayMode}</td>
                                            <td>{item.status}</td>
                                            <td><button className="btn btn-danger" onClick={()=>updatestatus(item._id)}>Update</button></td>
                                            <td><button className="btn btn-danger" onClick={()=>onorderdel(item._id)}>Delete</button></td>
                                        </tr>
                                    )
                                }
                                </table><br/><br/>
                                {orderdata.length} orders found<br/>
                                Rs.{billamt}/- is total bill <br/><br/>
                            </>:null
                    }
                    <h4>For New People</h4>
                  
                    <p><Link to="/signup">Register Here</Link> (Or) go back to <Link to="/">Home</Link><span className="glyphicon glyphicon-menu-right" aria-hidden="true"></span></p>
                </div>
            </div>

        </>
    )
}
export default SearchOrderId;