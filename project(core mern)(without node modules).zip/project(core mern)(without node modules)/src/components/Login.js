import axios from "axios";
import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import { userContext } from "../App";

function Login() {

    const[uname , setuname]=useState();
    const[pass , setpass]=useState();
    const[msg , setmsg] = useState();

    const navi = useNavigate();

    const {udata , setudata} = useContext(userContext)

    async function onlogin(e)
    {
        e.preventDefault()
        const logindata = {uname , pass};
        try
        {
            const resp = await axios.post("http://localhost:9000/api/login" , logindata)
            if(resp.status===200)
            {
                if(resp.data.statuscode===0)
                {
                    toast.warn("Incorrect Username/Password")
                }
                else 
                {
                    setudata(resp.data.userdata)
                    sessionStorage.setItem("userdata" ,JSON.stringify(resp.data.userdata));
                    if(resp.data.userdata.usertype==="admin")
                    {
                        navi("/adminhome")
                    }
                    else
                    {
                        navi("/home")
                    }
                }
            }
            else
            {
                setmsg("Some Problem Occured")
            }
        }
        catch(e)
        {
            setmsg(e.message)
        }
    }

    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">Login Page</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <h2>Login Form</h2>

                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">
                        <form name="form1" onSubmit={onlogin}>
                            <input type="email" name="un" placeholder="Email Address(username)" required=" " onChange={(e)=>setuname(e.target.value)}/>
                            <input type="password" name="pass" placeholder="Password" required=" " onChange={(e)=>setpass(e.target.value)}/>
                            <input type="submit" name="btn" value="Login" /><br/><br/>
                            {msg}
                        </form>
                    </div>
                    <h4>For New People</h4>
                  
                    <p><Link to="/signup">Register Here</Link> (Or) go back to <Link to="/">Home</Link><span className="glyphicon glyphicon-menu-right" aria-hidden="true"></span></p>
                </div>
            </div>

        </>
    )
}
export default Login;