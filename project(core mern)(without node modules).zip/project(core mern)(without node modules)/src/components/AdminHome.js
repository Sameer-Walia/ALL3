import { useContext } from "react";
import { userContext } from "../App";

function AdminHome() {

    const { udata } = useContext(userContext);

    return (
        <>
            <div class="register">
                <div class="container">
                        {
                            udata === null ?
                            <>
                                <h2>Welcome Guest</h2>
                            </> : <h2>Welcome {udata.pname}</h2>
                        }
                        {/* <h2>Welcome {udata.pname}</h2> */}
                </div>
            </div>
        </>
    )
}
export default AdminHome;