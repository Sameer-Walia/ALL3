const express = require('express')
const app = express()
const port = 9000
app.use(express.json());

var cors = require('cors')
app.use(cors())


const multer = require('multer')

const fs = require('fs');  // to delete image from folder

let mystorage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'public/uploads');//we will have to create folder in website where images will be saved
  },
  filename: (req, file, cb) => {
    var picname = Date.now() + '-' + file.originalname;//1711956271167-oil3.webp , date in millinano-seconds
    //milliseconds will be added with original filename and name will be stored in picname variable

    cb(null, picname);
  }
});
let upload = multer({ storage: mystorage })


const mongoose = require('mongoose');
const { type } = require('os');
mongoose.connect('mongodb://127.0.0.1:27017/projectdb').then(() => console.log('Connected to MongoDB'));

var SignupSchema = mongoose.Schema({ pname: String, phone: String, username: { type: String, unique: true }, password: String , usertype:String}, { versionKey: false })
var SignupModel = mongoose.model("signup", SignupSchema, "signup");// internal name , schema_name , real collection name

app.post("/api/signup", async (req, res) => 
{
  try
  {
    var newrecord = new SignupModel({ pname: req.body.name, phone: req.body.phone, username: req.body.uname, password: req.body.pass , usertype:"normal"})// this will create a temprory record into the model  , not in real connection

    var result = await newrecord.save();  // it will save the record into real collection
    // console.log(result)
    if (result) 
    {
      res.status(200).send({ statuscode: 1, msg: "Signup Successfull" })
    }
    else 
    {
      res.status(200).send({ statuscode: 0, msg: "Signup not successfull" })
    }
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  }
})

app.post("/api/login", async (req, res) =>
{
  try
  {

    var result = await SignupModel.find({ username: req.body.uname, password: req.body.pass }).select("-password").select("-phone");
    // result will become an array because find function return an array
    // console.log(result)
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, userdata: result[0] })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/searchuser", async (req, res) => 
{
  try
  {
    var result = await SignupModel.findOne({ username: req.query.un });
    // console.log(result)
    if (result) 
    {
      res.status(200).send({ statuscode: 1, searchdata: result })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/getallusers", async (req, res) => 
{
  try
  {
    var result = await SignupModel.find();
    // console.log(result)
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, usersdata: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.delete("/api/deluser/:uid", async (req, res) => 
{
  try
  {
    var result = await SignupModel.deleteOne({ _id: req.params.uid })  //{acknowledge:true , deletdCount:1 }
    // console.log(result)
    if (result.deletedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.put("/api/changepassword", async (req, res) => 
{
  try
  {
    var updatepass = await SignupModel.updateOne({ username: req.body.uname, password: req.body.currpass }, { $set: { password: req.body.newpass } })
    if (updatepass.modifiedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

var CatSchema = mongoose.Schema({ catname: { type: String, unique: true }, catpic: String }, { versionKey: false })
var CatModel = mongoose.model("category", CatSchema, "category");// internal name, schema_name, real collection_name

app.post("/api/savecategory", upload.single('cpic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = "noimage.jpg"
    }
    else 
    {
      picturename = req.file.filename
    }
    var newrecord = new CatModel({ catname: req.body.cname, catpic: picturename })
    var result = await newrecord.save();
    if (result) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }

})

app.get("/api/getallcat", async (req, res) => 
{
  try
  {
    var result = await CatModel.find()
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, categorydata: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.delete("/api/delcat", async (req, res) => 
{
  try
  {
    var result = await CatModel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.status(200).send({ statuscode: 1, msg: "Category Deleted Successfully" })
    }
    else 
    {
      res.status(200).send({ statuscode: 0, msg: "Category not Deleted" })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})


app.put("/api/updatecategory", upload.single('uppic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = req.body.oldpicname;//it will save current picname in this variable
    }
    else 
    {
      picturename = req.file.filename;

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }

    }

    var updateresult = await CatModel.updateOne({ _id: req.body.cid }, { $set: { catname: req.body.upname, catpic: picturename } });

    if (updateresult.modifiedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    console.log(e);
    res.status(500).send({statuscode:-1,msg:e.message})
  }
})

var productSchema = mongoose.Schema({ Catid: String, Name: { type: String, unique: true }, Rate: Number, Discount: Number, Stock: Number, Description: String, Picture: String, Addedon: String }, { versionKey: false })
var productmodel = mongoose.model("product", productSchema, "product")

app.post("/api/addproduct", upload.single('picture'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = "noimage.jpg";
    }
    else 
    {
      picturename = req.file.filename;
    }

    var newrecord = new productmodel({ Catid: req.body.catid, Name: req.body.pname, Rate: req.body.rate, Discount: req.body.dis, Stock: req.body.stock, Description: req.body.descp, Picture: picturename, Addedon: new Date() })

    var result = await newrecord.save()
    if (result) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/fetchproductbycatid", async (req, res) => 
{
  try
  {
    var result = await productmodel.find({ Catid: req.query.cid })
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.delete("/api/delproduct", async (req, res) =>
{
  try
  {
    var result = await productmodel.deleteOne({ _id: req.query.id })
    if (result.deletedCount === 1) 
    {
      res.status(200).send({ statuscode: 1, msg: "product deleted successfully" })
    }
    else 
    {
      res.status(200).send({ statuscode: 0, msg: "product not deleted" })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.put("/api/updateproduct", upload.single('uppic'), async (req, res) => 
{
  try
  {
    var picturename;
    if (!req.file) 
    {
      picturename = req.body.oldpicname;//it will save current picname in this variable
    }
    else 
    {
      picturename = req.file.filename;

      if (req.body.oldpicname !== "noimage.jpg") 
      {
        fs.unlinkSync(`public/uploads/${req.body.oldpicname}`);
      }
    }

    var updateresult = await productmodel.updateOne({ _id: req.body.productid }, { $set: { Catid: req.body.cid, Name: req.body.upname, Rate: req.body.uprate, Discount: req.body.updis, Stock: req.body.upstock, Description: req.body.updescp, Picture: picturename , Addedon:new Date()} });

    if (updateresult.modifiedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/fetchprodbycatid", async (req, res) => 
{
  try
  {
    var result = await productmodel.find({ Catid: req.query.cid })
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/fetchproductbyid", async (req, res) => 
{
  try
  {
    var result = await productmodel.find({ _id: req.query.id })
    // var result = await productmodel.findOne({ _id: req.query.id })
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, product: result[0] })
      // res.status(200).send({ statuscode: 1, product: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/fetchproductbyid1", async (req, res) => 
{
  try
  {
    var result = await productmodel.find({ _id: req.query.id })
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, product: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})


var cartSchema = mongoose.Schema({pid:String , Picture: String, ProdName: String, Rate: Number, Qty: Number, TotalCost: Number, Username: String }, { versionKey: false })
var CartModel = mongoose.model("cart", cartSchema, "cart");// internal name, schema_name, real collection_name

app.post("/api/addtocart", async (req, res) => 
{
  try
  {
    var newrecord = new CartModel({ pid:req.body.pid ,Picture: req.body.picture, ProdName: req.body.pname, Rate: req.body.rate, Qty: req.body.qty, TotalCost: req.body.tc, Username: req.body.username })

    var result = await newrecord.save();

    if (result) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/getcart", async (req, res) => 
{
  try 
  {
    var result = await CartModel.find({ Username: req.query.un })
    if (result.length === 0)
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, cartinfo: result })
    }
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  }
})

app.delete("/api/delproduct/:id", async (req, res) => 
{
  try
  {
    var result = await CartModel.deleteOne({ _id: req.params.id })
    if (result.deletedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  }
})

var orderSchema = mongoose.Schema({address:Object,billamt:Number,username:String,OrderDate:String,PayMode:String,CardDetails:Object,OrderProducts:[Object],status:String},{versionKey:false})

var OrderModel = mongoose.model("finalorder",orderSchema,"finalorder");
app.post("/api/saveorder",async(req,res)=>
{
  try
  {
    var newrecord = new OrderModel({address:req.body.address,billamt:req.body.tbill,username:req.body.uname,OrderDate:new Date(),PayMode:req.body.pmode,CardDetails:req.body.carddetails,OrderProducts:req.body.cartinfo,status:"Payment received, processing"}) 

    var result = await newrecord.save();

    if(result)
    {
      res.status(200).send({statuscode:1})
    }
    else
    {
      res.status(200).send({statuscode:0})
    }  
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  } 
})

app.put("/api/updatestock",async(req,res)=>
{
  try
  {
    var cartdata = req.body.cartinfo;
    for(var x=0;x<cartdata.length;x++)
    {
      var updateresult = await productmodel.updateOne({_id: cartdata[x].pid}, {$inc:{"Stock":-cartdata[x].Qty}});
    }
    if(updateresult.modifiedCount===1)
    {
      res.status(200).send({statuscode:1})
    }
    else
    {
      res.status(200).send({statuscode:0})
    }
  }
  catch (e) 
  {
    console.log(e);
    res.status(500).send({statuscode:-1,msg:e.message})
  } 
})

app.delete("/api/deletecart",async(req,res)=>
{
  try
  {
    var result = await CartModel.deleteMany({Username:req.query.un})//{ acknowledged: true, deletedCount: ... }
    if(result.deletedCount>=1)
    {
      res.status(200).send({statuscode:1})
    }
    else
    {
      res.status(200).send({statuscode:0})
    }    
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  } 
})

app.get("/api/getorderid",async(req,res)=>
{
  try
  {
    var result = await OrderModel.findOne({username:req.query.un}).sort({"OrderDate":-1});
    if(result)
    {
      res.status(200).send({statuscode:1,orderdata:result})
    }
    else
    {
      res.status(200).send({statuscode:0})
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/getallorders",async(req,res)=>
{
  try
  {
    var result = await OrderModel.find().sort({"OrderDate":-1})
    //result will become an array because find function returns an array
    if(result.length===0)
    {
      res.status(200).send({statuscode:0})
    }
    else
    {
      res.status(200).send({statuscode:1,ordersdata:result})
    }    
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.delete("/api/delorder/:id", async (req, res) => 
{
  try
  {
    var result = await OrderModel.deleteOne({ _id: req.params.id })
    if (result.deletedCount === 1) 
    {
      res.status(200).send({ statuscode: 1 })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch (e) 
  {
    res.status(500).send({ statuscode: -1, errmsg: e.message })
  }
})

app.put("/api/updatestatus",async(req,res)=>
{
  try
  {
    var updateresult = await OrderModel.updateOne({_id: req.body.orderid}, { $set: {status:req.body.newst}});

    if(updateresult.modifiedCount===1)
    {
      res.status(200).send({statuscode:1})
    }
    else
    {
      res.status(200).send({statuscode:0})
    }
  }
  catch(e)
  {
    console.log(e);
    res.status(500).send({statuscode:-1,msg:"Some error occured"})
  }
})

app.get("/api/getorderproducts",async(req,res)=>
{
  var result = await OrderModel.findOne({_id:req.query.orderno});
  if(result.length===0)
  {
    res.status(200).send({statuscode:0})
  }
  else
  {
    res.status(200).send({statuscode:1,items:result.OrderProducts})
  }    
})

app.get("/api/getuserorders",async(req,res)=>
{
  var result = await OrderModel.find({username:req.query.un}).sort({"OrderDate":-1})

  if(result.length===0)
  {
    res.status(200).send({statuscode:0})
  }
  else
  {
    res.status(200).send({statuscode:1,ordersdata:result})
  }    
})

app.get("/api/searchproducts",async(req,res)=>
// rest function in header
{
  var searchtext = req.query.q;
  var result = await productmodel.find({Name: { $regex: '.*' + searchtext ,$options:'i' }})
  //result will become an array because find function returns an array
  if(result.length===0)
  {
    res.status(200).send({statuscode:0})
  }
  else
  {
    res.status(200).send({statuscode:1,proddata:result})
  }    
})

app.get("/api/fetchlatestprods", async (req, res) => 
{
  try
  {
    var result = await productmodel.find().sort({"AddedOn":-1}).limit(6)
    //result will become an array because find function returns an array
    if (result.length === 0) 
    {
      res.status(200).send({ statuscode: 0 })
    }
    else 
    {
      res.status(200).send({ statuscode: 1, proddata: result })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/SearchOrderId", async (req, res) => 
{
  try
  {
    var result = await OrderModel.find({_id:req.query.un})
    //result will become an array because find function returns an array
    if (result.length===1) 
    {
      res.status(200).send({ statuscode: 1, proddata: result })
    }
    else 
    {
      res.status(200).send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})


var contactSchema = mongoose.Schema({username:String , name:String , email:String , message:String ,  ContactOn:String})
var contactModel = mongoose.model("contactus" , contactSchema , "contactus")

app.post("/api/ContactUs" , async(req , res)=>
{
  try
  {
    var newrecord = new contactModel({username:req.body.udata , name:req.body.uname ,email:req.body.email ,message:req.body.message, ContactOn:new Date()} ,{versionKey:false} )
    var result = await newrecord.save()
    {
      if(result)
      {
        res.status(200).send({statuscode:1})
      }
      else
      {
        res.status(200).send({statuscode:0})
      }  
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.get("/api/getalladmincontact" , async(req , res)=>
{
  try
  {
    var result = await contactModel.find().sort({"ContactOn":-1})
    {
      if(result.length===0)
      {
        res.status(200).send({statuscode:0})
      }
      else
      {
        res.status(200).send({statuscode:1 , contactdata:result})
      }  
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.delete("/api/delcontact/:id" , async(req , res)=>
{
  try
  {
    var result = await contactModel.deleteOne({_id:req.params.id})
    {
      if(result.deletedCount===1)
      {
        res.status(200).send({statuscode:1})
      }
      else
      {
        res.status(200).send({statuscode:0})
      }  
    }
  }
  catch(e)
  {
    res.status(500).send({statuscode:-1,errmsg:e.message})
  }
})

app.listen(port, () => {
  console.log(`Server is running on port ${port}`)
})