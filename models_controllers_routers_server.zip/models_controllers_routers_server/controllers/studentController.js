const signupmodel = require("../models/studentmodel");

exports.signup  =  async (req , res)=>
{
  try
  {
    const result = await signupmodel.create(req.body)  // .create() already does new internally.

    // const newrecord = new signupmodel({ name: req.body.name, phone: req.body.phone, email: req.body.email, age:req.body.age ,      city:req.body.city , gender:req.body.gender  }) 
    // const result = await newrecord.save()

    if(result)
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0 })
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.fetchalluser  =  async (req , res)=>
{
  try
  {
    const result = await signupmodel.find()
    if (result.length===0)
    {
      res.send({ statuscode: 0 })
    }
    else 
    {
      res.send({ statuscode: 1  , users:result})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.deluser = async (req , res)=>
{
  try
  {
    const result = await signupmodel.deleteOne({_id:req.query.id})
    if(result.deletedCount===1)
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode: 0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}

exports.updateuser = async (req , res)=>
{
  try
  {
    const result = await signupmodel.updateOne({_id:req.body.id} , { $set: {name:req.body.name , phone:req.body.phone , email:req.body.email , age:req.body.age , city:req.body.city , gender:req.body.gender }})

    if (result.modifiedCount===1)
    {
      res.send({ statuscode: 1 })
    }
    else 
    {
      res.send({ statuscode:0})
    }
  }
  catch(e)
  {
    res.send({statuscode:-1})
    console.log(e.message)
  }
}
