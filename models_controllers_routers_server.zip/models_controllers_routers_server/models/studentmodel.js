const mongoose = require('mongoose');

const SignupSchema = new mongoose.Schema({ 
    name: {
        type:String,
        required: true
    },
    phone: {
        type:Number,
        required: true,
        unique: true,
    }, 
    email: { 
        type:String,
        required: true,
        unique: true 
    },
    age: {
        type:Number,
        required:true
    },
    city:{
        type:String,
        required: true
    } , 
    gender:{
        type:String,
        required: true
    }
})

module.exports = mongoose.model("signup" , SignupSchema ,"signup")