const express = require('express')
const mongoose = require('mongoose');
const app = express()
const port = 10000
app.use(express.json());

const cors = require('cors')   
app.use(cors())

const studentroutes = require('./routes/studentRoutes');
app.use('/api' , studentroutes)


mongoose.connect('mongodb://127.0.0.1:27017/MCRS').then(() => console.log('Connected to MongoDB'));


// const SignupSchema = mongoose.Schema({ name: String, phone: String, email: { type: String, unique: true }, age: Number , city:String , gender:String}, { versionKey: false })
// const SignupModel = mongoose.model("signup", SignupSchema, "signup");

// app.post("/api/register" , async (req , res)=>
// {
//   try
//   {
//     const newrecord = new SignupModel({ name: req.body.name, phone: req.body.phone, email: req.body.email, age:req.body.age , city:req.body.city , gender:req.body.gender  }) 

//     const result = await newrecord.save()
//     if (result)
//     {
//       res.send({ statuscode: 1 })
//     }
//     else 
//     {
//       res.send({ statuscode: 0 })
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
    
// })

// app.get("/api/fetchalluser" , async (req , res)=>
// {
//   try
//   {
//     const result = await SignupModel.find()
//     if (result.length===0)
//     {
//       res.send({ statuscode: 0 })
//     }
//     else 
//     {
//       res.send({ statuscode: 1  , users:result})
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
// })

// app.delete("/api/deluser" , async (req , res)=>
// {
//   try
//   {
//     const result = await SignupModel.deleteOne({_id:req.query.id})
//     if(result.deletedCount===1)
//     {
//       res.send({ statuscode: 1 })
//     }
//     else 
//     {
//       res.send({ statuscode: 0})
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
// })

// app.put("/api/updateuser" , async (req , res)=>
// {
//   try
//   {

//     const result = await SignupModel.updateOne({_id:req.body.id} , { $set: {name:req.body.name , phone:req.body.phone , email:req.body.email , age:req.body.age , city:req.body.city , gender:req.body.gender }})

//     if (result.modifiedCount===1)
//     {
//       res.send({ statuscode: 1 })
//     }
//     else 
//     {
//       res.send({ statuscode:0})
//     }
//   }
//   catch(e)
//   {
//     res.send({statuscode:-1})
//     console.log(e.message)
//   }
// })




app.listen(port, () => {
  console.log(`Server is running on port ${port}`)
})