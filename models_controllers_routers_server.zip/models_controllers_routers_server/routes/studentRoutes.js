const express = require('express')
const router = express.Router();
const studentcontroller  = require("../controllers/studentController");

router.post("/signup" , studentcontroller.signup)

router.get("/fetchalluser" , studentcontroller.fetchalluser)

router.delete("/deluser" , studentcontroller.deluser)

router.put("/updateuser" , studentcontroller.updateuser)

module.exports = router;