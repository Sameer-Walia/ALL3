import { ToastContainer } from 'react-toastify';
import './App.css';
import Register from './components/Register';

function App() {
  return (
    <div className="App">
      <Register/>
      <ToastContainer theme='colored'/>
    </div>
  );
}

export default App;
