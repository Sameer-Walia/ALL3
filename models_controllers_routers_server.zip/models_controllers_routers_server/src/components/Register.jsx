import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { toast } from 'react-toastify'

function Register() {

    const [name , setname] = useState()
    const [phone , setphone] = useState()
    const [email , setemail] = useState()
    const [age , setage] = useState()
    const [city , setcity] = useState()
    const [gender , setgender] = useState()
    const [id , setid] = useState()
    const [edit , setedit] = useState(false)
    const [fetchallusers , setfetchallusers] = useState([])

    async function register(e)
    {
        e.preventDefault()
        try
        {
            if(edit===false)
            {
                const data = {name , phone , email , age , city , gender}

                const resp = await axios.post(`http://localhost:10000/api/signup` , data)

                if(resp.data.statuscode===1)
                {
                    toast.success("User Register Successfully ")
                    allusers()
                }
                else if(resp.data.statuscode===0)
                {
                    toast.error("User Not Register Successfully ")
                }
                else
                {
                    toast.error("Some Problem Occured")
                }
            }
        }
        catch(e)
        {
            toast.error("Error Occurred "+ e.message)
        }
        
    }

    useEffect(()=>
    {
        allusers()
    },[])

    async function allusers()
    {
        try
        {
            const resp = await axios.get(`http://localhost:10000/api/fetchalluser`)
            if(resp.data.statuscode===1)
            {
                setfetchallusers(resp.data.users)
            }
            else if(resp.data.statuscode===0)
            {
                toast.error("User Not Register Successfully ")
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occurred "+ e.message)
        }
    }

    function onupdate(data)
    {
        setedit(true)
        setname(data.name)
        setphone(data.phone)
        setemail(data.email)
        setage(data.age)
        setcity(data.city)
        setgender(data.gender)
        setid(data._id)
    }
    async function updateuser()
    {
        try
        {
            const updata = {name , phone , email , age , city , gender , id}
            const resp = await axios.put(`http://localhost:10000/api/updateuser` , updata)
            if(resp.data.statuscode===1)
            {
                toast.success("User Updated Successfully ")
                allusers()
            }
            else if(resp.data.statuscode===0)
            {
                toast.error("User Not Updated Successfully ")
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occurred "+ e.message)
        }
    }

    async function canceldb()
    {
        setedit(false)
        setname("")
        setphone("")
        setemail("")
        setage("")
        setcity("")
        setgender("")
    }


    async function ondelete(id)
    {
        try
        {
            var pass = window.confirm("Are you sure to Delete")
            if(pass===true)
            {
                const resp = await axios.delete(`http://localhost:10000/api/deluser?id=${id}`)
               
                if(resp.data.statuscode===1)
                {
                    toast.success("User Deleted Successfully")
                    allusers()
                }
                else if(resp.data.statuscode===0)
                {
                    toast.warn("User Not Deleted Successfully")
                }
                else
                {
                    toast.error("some problem occured")
                }
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }


    return (
        <>
        <div className="register-container">
            <h2 className="register-title">Register</h2>
            <form className="register-form" onSubmit={register}>
                <div className="form-group">
                    <input type="text" id="name" name="name" value={name} required placeholder="Enter your name" onChange={(e)=>setname(e.target.value)} />
                </div>

                <div className="form-group">
                    <input type="tel" id="phone" value={phone} minLength="10" maxLength="10" name="phone" required placeholder="Enter your number" onChange={(e)=>setphone(e.target.value)} />
                </div>

                <div className="form-group">
                    <input type="email" id="email" value={email} name="email" required placeholder="Enter your email" onChange={(e)=>setemail(e.target.value)} />
                </div>

                <div className="form-group">
                    <input type="number" id="age" name="age" value={age} required placeholder="Enter your age" onChange={(e)=>setage(e.target.value)}/>
                </div>

                <div className="form-group">
                    <input type="text" id="city" name="city" value={city} required placeholder="Enter your city" onChange={(e)=>setcity(e.target.value)}/>
                </div>

                <div className="form-group">
                    <select id="gender" name="gender" value={gender} required onChange={(e)=>setgender(e.target.value)}>
                        <option value="">Select gender</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                        <option value="other">Other</option>
                    </select>
                </div>
                {
                    edit===false?
                    <>
                        <input type="submit" className="register-btn" value="register"/>    
                    </>:
                    <>
                        <input type="button" className="register-btn" value="Update" onClick={updateuser} /><br/><br/>
                        <input type="button" className="register-btn" value="Cancel" onClick={canceldb} />
                    </>
                }
                
            </form>
        </div>

        <div className='tablecontainer' >
            {
                fetchallusers.length > 0 ? 
                    <>
                        <h2>Registered Students</h2>
                        <table className="students-table">
                            <thead>
                            <tr>
                                <th>Name</th>
                                <th>Phone</th>
                                <th>Email</th>
                                <th>Age</th>
                                <th>City</th>
                                <th>Gender</th>
                                <th>Update</th>
                                <th>Delete</th>
                            </tr>
                            </thead>
                            <tbody>
                            {
                                fetchallusers.map((item, index) => 
                                <tr key={index}>
                                    <td>{item.name}</td>
                                    <td>{item.phone}</td>
                                    <td>{item.email}</td>
                                    <td>{item.age}</td>
                                    <td>{item.city}</td>
                                    <td>{item.gender}</td>
                                    <td><button className="btn btn-primary" onClick={()=>onupdate(item)}>Update</button></td>
                                    <td><button className="btn btn-danger" onClick={()=>ondelete(item._id)}>Delete</button></td>
                                </tr>
                            )}
                            </tbody>
                        </table>
                    </>
                : null
            }
        </div>

        </>

    )
}

export default Register
