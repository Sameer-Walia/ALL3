import { useContext, useEffect } from "react";
import { userContext } from "../App";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function AdminHome() {

    const { udata } = useContext(userContext);
    const navi = useNavigate()

    useEffect(()=>
    {
        if(sessionStorage.getItem("userdata")===null)
        {
            navi("/login")
            toast.error("please login to access the page")
        }
        else
        {
            var uinfo = JSON.parse(sessionStorage.getItem("userdata"))
            if(uinfo.usertype!=="admin")
            {
                navi("/login")
                toast.error("please login to access the admin page") 
            }
        }
    },[])

    return (
        <>
            <div class="register">
                <div class="container">
                        {
                            udata === null ?
                            <>
                                <h2>Welcome Guest</h2>
                            </> : <h2>Welcome {udata.pname}</h2>
                        }
                        {/* <h2>Welcome {udata.pname}</h2> */}
                </div>
            </div>
        </>
    )
}
export default AdminHome;