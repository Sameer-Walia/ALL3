import axios from "axios";
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function UsersList() {

    const[membersdata , setmembersdata]=useState([]);

    async function fetchUsers()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getallusers` , {headers : {authorization:sessionStorage.getItem("jsontoken")}});
          
            if(resp.data.statuscode===1)
            {
                setmembersdata(resp.data.usersdata)
            }
            else if(resp.data.statuscode===0)
            {
                setmembersdata([]);
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
    }

    
    useEffect(()=>
    {
        fetchUsers();
    },[])

    async function onmemdel(id)
    {
        const userresp = window.confirm("Are you sure to Delete")

        if(userresp===true)
        {
            const resp = await axios.delete(`${process.env.REACT_APP_APIURL}/api/deluser/${id}`)
            
            if(resp.data.statuscode===1)
            {
                toast.success("User Deleted Successfull")
                fetchUsers();
            }
            else if(resp.data.statuscode===0)
            {
                toast.error("User not Deleted")
            }
            else
            {
                toast.error("Some Problem Occured")
            }
        }  
    }


    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">UsersList</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    {
                        membersdata.length>0?
                        <>
                            <h2>List Of Users</h2><br/>
                            <table className="table table-striped timetable_sub">
                                <tbody>
                                    <tr>
                                        <th>Name</th>
                                        <th>Phone</th>
                                        <th>Username</th>
                                        <th>Delete</th>
                                    </tr>
                                 </tbody>
                            {
                                membersdata.map((item , index)=>
                                    <tr key={index}>
                                        <td>{item.pname}</td>
                                        <td>{item.phone}</td>
                                        <td>{item.username}</td>
                                        <td><button className="btn btn-danger" onClick={()=>onmemdel(item._id)}>Delete</button></td>
                                    </tr>
                                )
                            }
                           
                            </table><br/><br/>
                            {membersdata.length} members found
                        </>:<h2>No User Found</h2>
                    }
                </div>
            </div>

        </>
    )
}
export default UsersList;