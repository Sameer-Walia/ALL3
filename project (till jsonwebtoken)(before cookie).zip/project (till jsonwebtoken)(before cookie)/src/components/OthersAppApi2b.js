import axios from "axios";
import { useEffect, useState } from "react";
import {  Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function OthersAppApi2b() { 

    const[city , setcity]=useState("");
    const[data , setdata]=useState({});
    const [loading, setloading] = useState(false);
    
    async function fetchweather(e)
    {
        e.preventDefault()
        try
        {
            setloading(true);
            const resp = await axios.get(`https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=dd03a72bcc5420924bfdae4a6dc106e9&units=metric`)
            if(resp)
            {
                setdata(resp.data)
            }
            else
            {
                toast.warn("Some Problem Occured")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally 
        {
            setloading(false);
        }
    }

    
    return (
        <>
            <div className="breadcrumbs">
                <div className="container">
                    <ol className="breadcrumb breadcrumb1 animated wow slideInLeft" data-wow-delay=".5s">
                        <li><Link to="/"><span className="glyphicon glyphicon-home" aria-hidden="true"></span>Home</Link></li>
                        <li className="active">3rd App Api</li>
                    </ol>
                </div>
            </div>

            <div className="login">
                <div className="container">
                    <h2>Weather Forcast</h2>
                    
                    <div className="login-form-grids animated wow slideInUp" data-wow-delay=".5s">

                        <form name="form1" onSubmit={fetchweather}>  
                            <select name="city"  className="form-control" required onChange={(e)=>setcity(e.target.value)} >  
                                <option value="">Choose City</option>
                                <option>Jalandhar</option>
                                <option>Ludhiana </option>
                                <option>Amritsar</option>
                                <option>Bathinda</option>
                                <option>Kapurthala</option>
                                <option>Beas</option>
                            </select>

                            {
                                loading? 
                                <div className="loader-container">
                                    <img src="images/loader.gif" alt="loader" className="loader" />
                                </div>:<input type="submit" name="btn2" value="Show Weather" />
                            }

                        </form><br/>

                        <div className="weather-result">
                            <h3 className="text-center">Weather in {data?.name}</h3>
                            <p>Temperature: {data?.main?.temp} °C</p>
                            <p>Feels Like: {data?.main?.feels_like} °C</p>
                            <p>Humidity: {data?.main?.humidity}%</p>
                            <p>Condition: {data?.weather?.[0].description}</p>
                        </div>

                        {/* {
                            Object.keys(data).length>0?
                                <div className="weather-result">
                                    <h3 className="text-center">Weather in {data.name}</h3>
                                    <p>Temperature: {data.main.temp} °C</p>
                                    <p>Feels Like: {data.main.feels_like} °C</p>
                                    <p>Humidity: {data.main.humidity}%</p>
                                    <p>Condition: {data.weather[0].description}</p>
                                </div>:null
                        } */}

                    </div>
                </div>
            </div><br/><br/>

        </>
    )
}
export default OthersAppApi2b;