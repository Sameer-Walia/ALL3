import axios from 'axios';
import { useEffect, useState } from 'react'
import { toast } from 'react-toastify';

function useFetchCategories() {

    const[catdata , setcatdata] = useState([]);
    const[loader , setloader] = useState(true);
    
    async function fetchallcat()
    {
        try
        {
            const resp = await axios.get(`${process.env.REACT_APP_APIURL}/api/getallcat`)
          
            if(resp.data.statuscode===1)
            {
                setcatdata(resp.data.categorydata)
            }
            else if(resp.data.statuscode===0)
            {
                setcatdata([]);
                toast.error("No Categories found")
            }
            else
            {
                toast.error("Some Problem Occured , try again")
            }
        }
        catch(e)
        {
            toast.error("Error Occured " + e.message)
        }
        finally
        {
            setloader(false)
        }
    }

    
    useEffect(()=>
    {
        fetchallcat();
    },[])


  return {catdata , setcatdata , loader , fetchallcat}
}

export default useFetchCategories;
